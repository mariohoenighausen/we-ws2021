<template>
  <div class="hero-container">
    <h1>Mario Hönighausen</h1>
  </div>
</template>

<script>
export default {
  name: "Hero"
}
</script>

<style scoped>
.hero-container{
  display: flex;
  justify-content: center;
}
</style>