export default {
  '/': 'Home',
  '/about': 'About',
  '/tasks': 'Tasks',
  '/contact': 'Contact'
}
